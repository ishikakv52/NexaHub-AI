"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from VoiceAssistant.remedies.views import ai_chat
from django.urls import path
from django.conf.urls.static import static
from django.urls import path, include
from django.conf import settings
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('accounts.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/subscriptions/', include('subscriptions.urls')),
    path('', include('ImageToText.urls')),
    path('voice-to-text/', include('VoiceToText.urls')),
    path("tts/", include("TextToSpeech.urls")),
    path('texttospeech/', include('TextToSpeech.urls')),
    path("remedies/", include("VoiceAssistant.remedies.urls")),  # ← SIRF YEH CHANGE KIYA
    path("ai-chat/", ai_chat),
    path('', include('VoiceAssistant.VoiceAssistant.urls')),
    path(
'workout/',
include(
'VoiceAssistant.workout.urls'
)),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)